#include <stdio.h>
int main()
{
    int i,a,b,c;
    float j;
    printf("Enter Item Number:");
    scanf("%d",&i);
    printf("Enter unit price:");
    scanf("%f",&j);
    printf("Enter purchase date(mm/dd/yyyy):");
    scanf("%d/%d/%d",&a,&b,&c);
    printf("Item             Unit            Purchase\n");
    printf("                 Price           Date\n");
    printf("%-15.4d $%4.2f%10d/%d/%d\n",i,j,a,b,c);
}