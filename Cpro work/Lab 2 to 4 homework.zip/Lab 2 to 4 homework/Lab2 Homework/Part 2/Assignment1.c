#include <stdio.h>
int main()
{
    int i,j,k;
    printf("ENTER A DATE(mm/dd/yyyy):");
    scanf("%d/%d/%d",&i,&j,&k);
    printf("YOU ENETERED THE DATE:%d%d%d\n",k,i,j);
}