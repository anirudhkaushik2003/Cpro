#include <stdio.h>
int main()
{
    int a, b, c, d, e, f;
    d = a;
    e = b;
    f = c;
    do
    {
        printf("Enter date (mm/dd/yy)(0/0/0 to terminate):");
        scanf("%2d/%2d/%2d", &a, &b, &c);
        if (f > c && c != 0)
        {
            f = c;
            d = a;
            e = b;
        }
        else
        {
            if (f == c && c != 0)
            {
                if (d > a && a != 0)
                {
                    d = a;
                    f = c;
                    e = b;
                }
            }
            else
            {
                if (d == a && a != 0)
                {
                    if (e > b && b != 0)
                    {
                        d = a;
                        f = c;
                        e = b;
                    }
                }
            }
        }                
    }while (a != 0 && b != 0 && c != 0);
    printf("The earliest date is:%.2d/%.2d/%.2d\n", d, e, f);
}